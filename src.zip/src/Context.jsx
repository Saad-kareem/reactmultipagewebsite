import React, { useContext, useEffect, useReducer } from "react";
import reducer from "./reducer";
// import SData from './components/SData';
// import Services from './components/Services';

const AppContext = React.createContext();

//  const API = SData;

const initialState = {
  name: "",
  image: "",
  //   services : [],
};

const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const UpdateHomePage = () => {
    return dispatch({
      type: "HOME_UPDATE",
      payload: {
        name: "Saad Karim",
        image: "../src/components/Images/Hero.svg",
      },
    });
  };
  const UpdateAboutPage = () => {
    return dispatch({
      type: "ABOUT_UPDATE",
      payload: {
        name: "Saad Ali",
        image: "../src/components/Images/about1.svg",
      },
    });
  };
  //Get API Data
  //    const getServices =  async (url) =>{
  //   try{
  //        const resp = await  fetch(url);
  //         const data = await resp.json();
  //          dispatch({type:"GET_SERVICES",payload: data});
  //   }catch(error){
  //      console.log(error);
  //   }
  //    }

  //   //  Call API
  //   useEffect(() =>{
  //         getServices(API);
  //   },[])

  return (
    <AppContext.Provider value={{ ...state, UpdateHomePage, UpdateAboutPage }}>
      {children}
    </AppContext.Provider>
  );
};

const useGlobalContext = () => {
  return useContext(AppContext);
};

export { AppContext, AppProvider, useGlobalContext };
