import card from "./ApiImages/Card1.jpg";
import andriod from "./ApiImages/andriod.jpg";
import digital from "./ApiImages/digital.jpg";
import software from "./ApiImages/software.jpg";
import Web from "./ApiImages/WEB1.jpg";
import App from "./ApiImages/App.png";

const SData = [
  {
    imgsrc: Web,
    title: "Web Development",
    Info: "We offer a full cycle of application design, integration and management services.",
    btn: "See More",
  },
  {
    imgsrc: andriod,
    title: "Android Development",
    Info: "With over a decade in the field, we have become a trusted name in Android apps.",
    btn: "See More",
  },
  {
    imgsrc: digital,
    title: "Digital Marketing",
    Info: "ith 34 years of experience in IT, ScienceSoft helps businesses across 30+ industries.",
    btn: "See More",
  },
  {
    imgsrc: software,
    title: "Software Development",
    Info: " Combining 34 years of experience in software development with a mature project. ",
    btn: "See More",
  },
  {
    imgsrc: App,
    title: "App Development",
    Info: "  ith 34 years of experience in IT APP DEVELOPMENT SERVICES  Our developers.",
    btn: "See More",
  },
  {
    imgsrc: card,
    title: "Website Development",
    Info: "250+ businesses, governmental and non-profit organizations use the websites.",
    btn: "See More",
  },
];
export default SData;
