import React, { useEffect } from "react";
import HeroSection from "./HeroSection";
import { useGlobalContext } from "../Context";

const Home = () => {
  const { UpdateHomePage } = useGlobalContext();
 useEffect(() => UpdateHomePage(), []);
    
  return (
    <>
      <HeroSection />
    </>
  );
};

export default Home;
